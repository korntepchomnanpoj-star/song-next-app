'use client';

import React, { useState } from 'react';

export default function ReviewList() {
  const [rating, setRating] = useState(5);

  return (
    <div className="bg-white rounded-xl shadow-md p-8 border border-gray-100 mt-8">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">รีวิวและความคิดเห็น</h2>

      {/* ส่วนให้ผู้ใช้พิมพ์รีวิว */}
      <div className="bg-gray-50 p-6 rounded-lg mb-8 border border-gray-200">
        <h3 className="font-bold text-gray-700 mb-4">เขียนรีวิวของคุณ</h3>

        <div className="mb-4">
          <label className="block text-gray-600 text-sm mb-2">ให้คะแนน ({rating} ดาว):</label>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                className={`text-3xl transition-transform hover:scale-110 focus:outline-none ${star <= rating ? "text-yellow-400" : "text-gray-300"
                  }`}
              >
                ★
              </button>
            ))}
          </div>
        </div>

        <textarea
          className="w-full p-3 border rounded-md mb-4 focus:outline-none focus:border-indigo-500"
          rows={3}
          placeholder="พิมพ์ความคิดเห็นของคุณที่นี่..."
        ></textarea>

        <button className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition">
          ส่งรีวิว
        </button>
      </div>

      {/* 
        ส่วนแสดงรีวิวเก่าที่ถูกลบออกไปชั่วคราว
        เตรียมไว้สำหรับเชื่อมฐานข้อมูลดึงรีวิวของแต่ละเกมมาโชว์ 
      */}
      <div className="text-center py-6 text-gray-400">
        <p>ยังไม่มีรีวิวสำหรับเกมนี้ เป็นคนแรกที่รีวิวสิ!</p>
      </div>

    </div>
  );
}