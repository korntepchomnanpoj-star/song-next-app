'use client';

import React, { useState } from 'react';
import Navbar from './components/Navbar';
import GameCard from './components/GameCard';

export default function HomePage() {
  const top10Games = [
    {
      id: 1,
      title: "Dinkum",
      category: "Simulation",
      image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/1062520/header.jpg",
      platforms: ["PC", "Switch"]
    },
    {
      id: 2,
      title: "Stardew Valley",
      category: "Farming",
      image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/413150/header.jpg",
      platforms: ["PC", "PlayStation", "Xbox", "Switch", "iOS", "Android"]
    },
    {
      id: 3,
      title: "Townscaper",
      category: "Building",
      image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/1291340/header.jpg",
      platforms: ["PC", "PlayStation", "Xbox", "Switch", "iOS", "Android"]
    },
    {
      id: 4,
      title: "Dorfromantik",
      category: "Building",
      image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/1455840/header.jpg",
      platforms: ["PC", "Switch"]
    },
    {
      id: 5,
      title: "Slime Rancher",
      category: "Farming",
      image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/433340/header.jpg",
      platforms: ["PC", "PlayStation", "Xbox", "Switch"]
    },
    {
      id: 6,
      title: "Terraria",
      category: "Action-Adventure",
      image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/105600/header.jpg",
      platforms: ["PC", "PlayStation", "Xbox", "Switch", "iOS", "Android"]
    },
    {
      id: 7,
      title: "Insaniquarium Deluxe",
      category: "Simulation",
      image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/3320/header.jpg",
      platforms: ["PC"]
    },
    {
      id: 8,
      title: "Minecraft Dungeons",
      category: "Action-Adventure",
      image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/1672970/header.jpg",
      platforms: ["PC", "PlayStation", "Xbox", "Switch"]
    },
    {
      id: 9,
      title: "Subnautica",
      category: "Action-Adventure",
      image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/264710/header.jpg",
      platforms: ["PC", "PlayStation", "Xbox", "Switch"]
    },
    {
      id: 10,
      title: "Jurassic World Evolution 2",
      category: "Simulation",
      image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/1244460/header.jpg",
      platforms: ["PC", "PlayStation", "Xbox"]
    },
  ];

  const [selectedCategory, setSelectedCategory] = useState("ทั้งหมด");
  const [selectedPlatform, setSelectedPlatform] = useState("ทั้งหมด");

  const categories = ["ทั้งหมด", "Simulation", "Farming", "Building", "Action-Adventure"];
  const platformsList = ["ทั้งหมด", "PC", "PlayStation", "Xbox", "Switch", "iOS", "Android"];

  const filteredGames = top10Games.filter((game) => {
    const matchCategory = selectedCategory === "ทั้งหมด" || game.category === selectedCategory;
    const matchPlatform = selectedPlatform === "ทั้งหมด" || game.platforms.includes(selectedPlatform);
    return matchCategory && matchPlatform;
  });

  return (
    <div className="min-h-screen bg-gray-50 font-sans">
      <Navbar />

      <main className="p-8 max-w-[95%] mx-auto">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-gray-800 mb-6">
            10 อันดับเกมเล่นสบายๆ ผ่อนคลายสมอง
          </h2>

          <div className="flex flex-col items-center gap-4">
            <div className="flex items-center gap-2 flex-wrap justify-center">
              <span className="font-bold text-gray-600 mr-2">หมวดหมู่:</span>
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                    selectedCategory === cat
                      ? "bg-gray-800 text-white shadow"
                      : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 flex-wrap justify-center">
              <span className="font-bold text-gray-600 mr-2">แพลตฟอร์ม:</span>
              {platformsList.map((plat) => (
                <button
                  key={plat}
                  onClick={() => setSelectedPlatform(plat)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                    selectedPlatform === plat
                      ? "bg-indigo-600 text-white shadow"
                      : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                  }`}
                >
                  {plat}
                </button>
              ))}
            </div>
          </div>
        </div>

        {filteredGames.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {filteredGames.map((game) => (
              <GameCard
                key={game.id}
                id={game.id}
                title={game.title}
                category={game.category}
                image={game.image}
                platforms={game.platforms}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-gray-400">
            <p className="text-lg">ไม่พบเกมตามเงื่อนไขที่เลือก</p>
          </div>
        )}
      </main>
    </div>
  );
}