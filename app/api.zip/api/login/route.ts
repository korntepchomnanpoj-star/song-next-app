import { NextResponse } from 'next/server';
import { pool } from '../../lib/db';

export async function POST(req: Request) {
    try {
        const { email, password } = await req.json();

        // ค้นหาอีเมลและรหัสผ่านใน Database
        const [rows]: any = await pool.query(
            'SELECT * FROM users WHERE email = ? AND password_hash = ?',
            [email, password]
        );

        if (rows.length > 0) {
            const user = rows[0];

            // เช็คว่าโดนแบนหรือเปล่า
            if (user.status !== 'active') {
                return NextResponse.json({ success: false, message: 'บัญชีของคุณถูกระงับการใช้งาน' });
            }

            // ส่งข้อมูลกลับไปให้หน้าเว็บ (ไม่ส่งรหัสผ่านกลับไป)
            return NextResponse.json({
                success: true,
                user: { id: user.user_id, username: user.username, email: user.email }
            });
        } else {
            return NextResponse.json({ success: false, message: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง' });
        }
    } catch (error) {
        return NextResponse.json({ success: false, message: 'เกิดข้อผิดพลาดของระบบ' }, { status: 500 });
    }
}