import { NextResponse } from 'next/server';
import { pool } from '../../lib/db';

export async function POST(req: Request) {
    try {
        const { username, email, password } = await req.json();

        // บันทึกลงตาราง users (ให้สถานะเริ่มต้นเป็น active)
        await pool.query(
            'INSERT INTO users (username, email, password_hash, status) VALUES (?, ?, ?, ?)',
            [username, email, password, 'active']
        );

        return NextResponse.json({ success: true, message: 'สมัครสมาชิกสำเร็จ!' });
    } catch (error) {
        return NextResponse.json({ success: false, message: 'อีเมลนี้ถูกใช้งานแล้ว หรือเกิดข้อผิดพลาด' }, { status: 500 });
    }
}